package com.hapramp.models;

public class CompetitionEntryResponse {
  private String message;

  public CompetitionEntryResponse() {
  }

  public CompetitionEntryResponse(String message) {
    this.message = message;
  }
}
