package com.hapramp.steem;

/**
 * Created by Ankit on 2/21/2018.
 */

public class LocalConfig {
  public static final String PARENT_PERMALINK = "hapramp";
  public static final String APP_TAG = "1ramp/1.2";
  public static final int BENEFICIARY_WEIGHT = 0; // 0% of payout
  public static final String BENEFICIARY_ACCOUNT = "hapramp";
}
