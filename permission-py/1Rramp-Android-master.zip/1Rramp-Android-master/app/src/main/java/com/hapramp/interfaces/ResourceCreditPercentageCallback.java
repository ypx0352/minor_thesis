package com.hapramp.interfaces;

public interface ResourceCreditPercentageCallback {
  void onRcPercentage(int percentage);
  void onRcPercentageError();
}
