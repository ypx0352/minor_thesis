package com.hapramp.utils;

public class CommunityIds {
  public static final int EXPLORE = 101;
  public static final int FEED = 0;
  public static final int ART = 1;
  public static final int DANCE = 2;
  public static final int TRAVEL = 3;
  public static final int LITERATURE = 4;
  public static final int FILM = 5;
  public static final int PHOTOGRAPHY = 6;
  public static final int FASHION = 7;
  public static final int DESIGN = 8;
  public static final int EDIT_BORDER = 404;
}
