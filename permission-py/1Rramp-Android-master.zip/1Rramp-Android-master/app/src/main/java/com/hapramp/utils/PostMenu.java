package com.hapramp.utils;

public class PostMenu {
  public static final String Delete = "Delete";
  public static final String Repost = "Repost";
  public static final String Share = "Share";
}
