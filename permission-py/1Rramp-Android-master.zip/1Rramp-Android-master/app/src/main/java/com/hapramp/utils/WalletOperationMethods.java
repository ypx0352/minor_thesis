package com.hapramp.utils;

public class WalletOperationMethods {
  public static final String OPERATION_POWER_UP = "transfer-to-vesting";
  public static final String OPERATION_POWER_DOWN = "withdraw-vesting";
  public static final String OPERATION_TRANSFER = "transfer";
  public static final String OPERATION_DELEGATE = "delegateVestingShares";
}

