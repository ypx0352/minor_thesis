package com.hapramp.utils;

public class TopicCreator {
  public static String createTopic(String text){
    return  text;
  }
}
