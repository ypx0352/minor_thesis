package com.hapramp.utils;

/**
 * Created by Ankit on 5/12/2018.
 */

public class CrashReporterKeys {
  public static final String UI_ACTION = "UI Action : ";
}
