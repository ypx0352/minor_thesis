package com.hapramp.draft;

public class DraftType {
  public static final String BLOG = "b";
  public static final String CONTEST = "c";
  public static final String SHORT_POST = "s";
}
